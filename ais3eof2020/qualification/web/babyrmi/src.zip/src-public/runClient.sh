#!/bin/bash
java com.kaibro.rmi.Client
