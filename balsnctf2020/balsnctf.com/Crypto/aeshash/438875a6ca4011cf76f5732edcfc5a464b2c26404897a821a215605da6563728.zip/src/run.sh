#!/bin/bash
exec 2>/dev/null

cd /home/aeshash/
timeout 300 ./chall
