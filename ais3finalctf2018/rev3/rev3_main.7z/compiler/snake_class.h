class Snake{
    public:
    static void Main(){
        Var p;
        p=Array::Alloc(30);
        String::Set(p,"8787UR87");
        Output::PrintString(p);
        while_true();
        }
    };
