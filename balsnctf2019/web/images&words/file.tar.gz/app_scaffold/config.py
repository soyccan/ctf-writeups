from pathlib import Path

UPLOAD_DIR = Path('png')
DEBUG = False
MAX_FILENAME_LEN = 32
MAX_TEXT_LEN = 1024
