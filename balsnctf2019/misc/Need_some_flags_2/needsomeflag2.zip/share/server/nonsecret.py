import os
def printlist(path):
  print os.listdir(path)
